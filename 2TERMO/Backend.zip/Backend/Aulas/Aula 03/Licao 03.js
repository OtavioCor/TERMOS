// Prática

const numero1 = 20; 
const numero2 = 5; 
const soma = numero1 + numero2; 
const subtracao = numero1 - numero2; 
const multiplicacao = numero1 * numero2; 
const divisao = numero1 / numero2; 
const resto = numero1 % numero2; 
console.log("Soma:", soma); 
console.log("Subtração:", subtracao); 
console.log("Multiplicação:", multiplicacao); 
console.log("Divisão:", divisao); 
console.log("Resto da divisão:", resto); 

////////////////////////////////////////////////////////////////////////////////////////

// Desafio 01

const nota1 = 7; 
const nota2 = 8; 
const nota3 = 9; 
const media = (nota1 + nota2 + nota3) / 3; 
console.log("Média:", media); 

////////////////////////////////////////////////////////////////////////////////////////

// Desafio 02

const produto = "Biscoito Palhacitos"; 
const preco = 25; 
const quantidade = 2; 
const total = preco * quantidade; 
console.log("Produto:", produto); 
console.log("Valor total:", total); 

